from .base import BaseTimer as BaseTimer
from .clock import Timer as Timer

__all__ = ["BaseTimer", "Timer"]
