from moderngl_window.context.base import BaseKeys


class Keys(BaseKeys):
    pass
