"""
Custom exceptions
"""


class ImproperlyConfigured(Exception):
    """Raised when finding faulty configuration"""

    pass
