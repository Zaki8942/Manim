"""The Manim CLI, and the available commands for ``manim``.

This page is a work in progress. Please run ``manim`` or ``manim --help`` in
your terminal to find more information on the following commands.

Available commands
------------------

.. autosummary::
   :toctree: ../reference

   cfg
   checkhealth
   init
   plugins
   render
"""
